import java.util.*;

// ===============================
// Product Interface
// ===============================
interface Product {
    void displayDetails();
}

// ===============================
// LegacyItem Class (Old System)
// ===============================
class LegacyItem {

    private int itemId;
    private String description;

    // Parameterized Constructor
    public LegacyItem(int itemId, String description) {
        this.itemId = itemId;
        this.description = description;
    }

    // print() method
    public void print() {
        System.out.println("Legacy Item -> ID: " + itemId +
                ", Description: " + description);
    }
}

// ===============================
// ProductAdapter Class (Adapter Pattern)
// ===============================
class ProductAdapter implements Product {

    private LegacyItem legacyItem;

    // Constructor accepts LegacyItem object
    public ProductAdapter(LegacyItem legacyItem) {
        this.legacyItem = legacyItem;
    }

    // Override displayDetails()
    public void displayDetails() {
        legacyItem.print();
    }
}

// ===============================
// NewProduct Class
// ===============================
class NewProduct implements Product {

    private String name;

    // Constructor accepts product name
    public NewProduct(String name) {
        this.name = name;
    }

    // Override displayDetails()
    public void displayDetails() {
        System.out.println("New Product -> Name: " + name);
    }
}

// ===============================
// InventoryManager Class (Singleton Pattern)
// ===============================
class InventoryManager {

    // Singleton Instance
    private static InventoryManager instance;

    // List of Product objects
    private List<Product> productList;

    // Private Constructor
    private InventoryManager() {
        productList = new ArrayList<>();
    }

    // getInstance() method
    public static InventoryManager getInstance() {

        if (instance == null) {
            instance = new InventoryManager();
        }

        return instance;
    }

    // addProduct() method
    public void addProduct(Product product) {
        productList.add(product);
    }

    // returnInventory() method (Iterator)
    public Iterator<Product> returnInventory() {
        return productList.iterator();
    }
}

// ===============================
// Main Class
// ===============================
public class InventorySystem {

    public static void main(String[] args) {

        // Create single instance (Singleton)
        InventoryManager manager =
                InventoryManager.getInstance();

        // Add NewProduct objects
        manager.addProduct(
                new NewProduct("Laptop"));

        manager.addProduct(
                new NewProduct("Keyboard"));

        // Add LegacyItem using Adapter
        LegacyItem old1 =
                new LegacyItem(101, "Old Monitor");

        LegacyItem old2 =
                new LegacyItem(102, "Old Printer");

        manager.addProduct(
                new ProductAdapter(old1));

        manager.addProduct(
                new ProductAdapter(old2));

        // Iterator to traverse inventory
        Iterator<Product> iterator =
                manager.returnInventory();

        System.out.println("Inventory Details:");

        while (iterator.hasNext()) {

            Product product =
                    iterator.next();

            product.displayDetails();
        }
    }
}