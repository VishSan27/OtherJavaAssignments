public class EmployeeTest {

    public static void main(String[] args) {

        // Full Time SWE
        FullTimeEmployee swe =
                new FullTimeEmployee(
                        "Akshay Gada",
                        "ABCDE1234F",
                        "12-07-2022",
                        "Software Engineer",
                        1001,
                        "SWE",
                        900000,
                        120000,
                        0
                );

        // Full Time HR
        FullTimeEmployee hr =
                new FullTimeEmployee(
                        "Reem Shawarma",
                        "PQRSX5678K",
                        "15-03-2021",
                        "HR Specialist",
                        1002,
                        "HR",
                        650000,
                        0,
                        90000
                );

        // Contract Employee
        ContractEmployee contract =
                new ContractEmployee(
                        "Thasti Nudle",
                        "LMNOP4321Z",
                        "01-11-2025",
                        "Security Consultant",
                        2001,
                        160,
                        1200
                );

        // Manager
        Manager manager =
                new Manager(
                        "Bahadur Momon",
                        "ZXCVB9876P",
                        "08-01-2020",
                        "Engineering Manager",
                        3001,
                        "SWE",
                        1500000,
                        250000,
                        0,
                        80000,   // Travel Allowance (TA)
                        40000    // Education Allowance
                );

        swe.displayFullTime();
        hr.displayFullTime();
        contract.displayContract();
        manager.displayManager();
    }
}