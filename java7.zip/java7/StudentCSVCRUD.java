import java.io.*;
import java.util.*;

public class StudentCSVCRUD {

    static String fileName = "Students.csv";

    public static void main(String[] args) {

        try {

            // CREATE file + header
            createFile();

            // INSERT initial rows
            insertInitialRows();

            // INSERT 3 new rows
            insertMoreRows();

            // UPDATE marks
            updateMarks();

            // CALCULATE percentage
            calculatePercentage();

            // DELETE one row
            deleteRow(2); // delete student with ID 2

            // DISPLAY final file
            displayFile();

            // EXCEPTION DEMO
            showException();

        }
        catch (IOException e) {
            System.out.println("IOException occurred: " + e.getMessage());
        }
    }

    // CREATE
    static void createFile() throws IOException {

        FileWriter fw = new FileWriter(fileName);

        fw.write("studentId,name,branch,marks1,marks2,marks3,marks4,marks5,percentage\n");

        fw.close();

        System.out.println("CREATE: Students.csv file created.");
    }

    // INSERT initial rows
    static void insertInitialRows() throws IOException {

        FileWriter fw = new FileWriter(fileName, true);

        fw.write("1,Vishesh,CSE,80,75,70,65,60,0\n");
        fw.write("2,Yug,IT,85,78,82,76,74,0\n");

        fw.close();

        System.out.println("INSERT: Initial rows added.");
    }

    // INSERT more rows
    static void insertMoreRows() throws IOException {

        FileWriter fw = new FileWriter(fileName, true);

        fw.write("3,Kashif,ME,88,77,66,0,0,0\n");
        fw.write("4,Prad,CE,90,89,85,0,0,0\n");
        fw.write("5,Ayush,EE,72,68,70,0,0,0\n");

        fw.close();

        System.out.println("INSERT: 3 more rows added with marks4 & marks5 = 0.");
    }

    // UPDATE marks
    static void updateMarks() throws IOException {

        List<String> lines = new ArrayList<>();

        BufferedReader br = new BufferedReader(new FileReader(fileName));

        String line;

        while ((line = br.readLine()) != null) {

            String[] data = line.split(",");

            if (!data[0].equals("studentId")) {

                // update marks4 & marks5
                if (data[6].equals("0"))
                    data[6] = "75";

                if (data[7].equals("0"))
                    data[7] = "80";

                line = String.join(",", data);
            }

            lines.add(line);
        }

        br.close();

        FileWriter fw = new FileWriter(fileName);

        for (String l : lines)
            fw.write(l + "\n");

        fw.close();

        System.out.println("UPDATE: Marks updated.");
    }

    // CALCULATE percentage
    static void calculatePercentage() throws IOException {

        List<String> lines = new ArrayList<>();

        BufferedReader br = new BufferedReader(new FileReader(fileName));

        String line;

        while ((line = br.readLine()) != null) {

            String[] data = line.split(",");

            if (!data[0].equals("studentId")) {

                int m1 = Integer.parseInt(data[3]);
                int m2 = Integer.parseInt(data[4]);
                int m3 = Integer.parseInt(data[5]);
                int m4 = Integer.parseInt(data[6]);
                int m5 = Integer.parseInt(data[7]);

                double percentage =
                        (m1 + m2 + m3 + m4 + m5) / 5.0;

                data[8] = String.valueOf(percentage);

                line = String.join(",", data);
            }

            lines.add(line);
        }

        br.close();

        FileWriter fw = new FileWriter(fileName);

        for (String l : lines)
            fw.write(l + "\n");

        fw.close();

        System.out.println("UPDATE: Percentage calculated.");
    }

    // DELETE row
    static void deleteRow(int studentId)
            throws IOException {

        List<String> lines = new ArrayList<>();

        BufferedReader br = new BufferedReader(new FileReader(fileName));

        String line;

        while ((line = br.readLine()) != null) {

            String[] data = line.split(",");

            if (data[0].equals("studentId") ||
                    Integer.parseInt(data[0]) != studentId) {

                lines.add(line);
            }
        }

        br.close();

        FileWriter fw = new FileWriter(fileName);

        for (String l : lines)
            fw.write(l + "\n");

        fw.close();

        System.out.println("DELETE: Row with ID "
                + studentId + " deleted.");
    }

    // DISPLAY file in table format
static void displayFile() throws IOException {

    BufferedReader br =
            new BufferedReader(new FileReader(fileName));

    String line;

    System.out.println("\nFINAL FILE CONTENT (TABLE FORMAT):\n");

    // Table Header
    System.out.printf(
        "%-10s %-10s %-8s %-7s %-7s %-7s %-7s %-7s %-10s\n",
        "ID","Name","Branch",
        "M1","M2","M3","M4","M5","Percent"
    );

    System.out.println(
        "--------------------------------------------------------------------------");

    while ((line = br.readLine()) != null) {

        if (line.startsWith("studentId"))
            continue; // skip header

        String[] data = line.split(",");

        System.out.printf(
            "%-10s %-10s %-8s %-7s %-7s %-7s %-7s %-7s %-10s\n",
            data[0], data[1], data[2],
            data[3], data[4], data[5],
            data[6], data[7], data[8]
        );
    }

    br.close();
}

    // EXCEPTION demonstration
    static void showException() {

        try {

            FileReader fr =
                    new FileReader("WrongFile.csv");

        }
        catch (IOException e) {

            System.out.println("\nEXCEPTION DEMO:");
            System.out.println("IOException caught: "
                    + e.getMessage());
        }
    }
}